package com.example.swatseal.androidlab1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Settings extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);
    }

    protected void homeSettings(View v)
    {
        if(v.getId() == R.id.button11)
        {
            Intent i = new Intent(Settings.this, Homepage.class);
            startActivity(i);
        }
    }

}
