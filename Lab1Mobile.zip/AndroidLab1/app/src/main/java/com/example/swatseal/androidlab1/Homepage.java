package com.example.swatseal.androidlab1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

/**
 * Created by SWAT SEAL on 4/2/2018.
 */

public class Homepage extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);
    }

    protected void onHelpClick(View v)
    {
        if(v.getId() == R.id.button9)
        {
            Intent i = new Intent(Homepage.this, Help.class);
            startActivity(i);
        }
    }
    protected void onSettingClick(View v)
    {
        if(v.getId() == R.id.button6)
        {
            Intent i = new Intent(Homepage.this, Settings.class);
            startActivity(i);
        }
    }
    protected void onLogoutHomepage(View v)
    {
        Intent i = new Intent(Homepage.this, MainActivity.class);
        startActivity(i);
    }
}
