package com.example.swatseal.androidlab1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

public class Help extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);

    }

    protected void helpHome(View v)
    {
        if(v.getId() == R.id.button10)
        {
            Intent i = new Intent(Help.this, Homepage.class);
            startActivity(i);
        }
    }
}
