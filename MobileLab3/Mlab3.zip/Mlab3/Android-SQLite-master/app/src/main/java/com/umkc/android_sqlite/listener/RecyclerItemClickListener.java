package com.umkc.android_sqlite.listener;

import android.view.View;

/**
 *
 */
public interface RecyclerItemClickListener {

    void onItemClick(int position, View view);
}
