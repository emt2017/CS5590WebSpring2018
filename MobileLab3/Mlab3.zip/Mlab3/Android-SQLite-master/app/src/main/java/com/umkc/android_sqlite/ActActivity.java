package com.umkc.android_sqlite;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.umkc.android_sqlite.db.SQLiteDB;
import com.umkc.android_sqlite.model.Contact;
import com.umkc.android_sqlite.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 *
 */
public class ActActivity extends AppCompatActivity implements View.OnClickListener{
    private static final int REQ_CODE_SPEECH_INPUT = 1;
    private static final int SPEECH_REQUEST_CODE = 0;
    private TextView phoneText;
    private EditText personName;
    private TextView phone;
    String newText;
    TextToSpeech toSpeech;

    private Button btnAdd, btnEdit, btnDelete, btnDone;
    private ImageButton btnSpeak;

    private SQLiteDB sqLiteDB;
    private Contact contact;

    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    public static void start(Context context){
        Intent intent = new Intent(context, ActActivity.class);
        context.startActivity(intent);
    }

    public static void start(Context context, Contact contact){
        Intent intent = new Intent(context, ActActivity.class);
        intent.putExtra(ActActivity.class.getSimpleName(), contact);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act);

        TextView personName = (TextView) findViewById(com.umkc.android_sqlite.R.id.personText);
        phone = (TextView) findViewById(com.umkc.android_sqlite.R.id.phoneText);

        btnAdd = (Button) findViewById(com.umkc.android_sqlite.R.id.btnAdd);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        btnDone = (Button) findViewById(R.id.btnDone);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);

        btnAdd.setOnClickListener(this);
        btnEdit.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnDone.setOnClickListener(this);
        btnSpeak.setOnClickListener(this);

        contact = getIntent().getParcelableExtra(ActActivity.class.getSimpleName());
        if(contact != null){
            btnAdd.setVisibility(View.GONE);
            btnDelete.setVisibility(View.GONE);
            personName.setText(contact.getName());
            phone.setText(contact.getPhone());
        }else{
            btnEdit.setVisibility(View.GONE);
            btnDone.setVisibility(View.GONE);
        }

        sqLiteDB = new SQLiteDB(this);

    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hello, How can I help you?");
        try {
            //toSpeech.speak("What is your name",TextToSpeech.QUEUE_FLUSH,null);
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {

        }
    }

    private void usingSharedPreferences(String n)
    {
        preferences = getSharedPreferences("com.umkc.android_sqlite", Context.MODE_PRIVATE);
        editor = preferences.edit();
        editor.putString("NAME", n).apply();
    }

    // This callback is invoked when the Speech Recognizer returns.
// This is where you process the intent and extract the speech text from the intent.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String spokenText = results.get(0);
                    // Do something with spokenText
                    //phone.setText(spokenText);
                    contact.setPhone(spokenText);
                    sqLiteDB.update(contact);
                    phone.setText(contact.getPhone());

                }
            }
        }
    }

    @Override
    public void onClick(View v) {

        //String name = personName.getText().toString();
        //String ph = phone.getText().toString();
        String ph = "";
        if(v == btnAdd){
            contact = new Contact();
            contact.setName(personName.getText().toString());
            contact.setPhone(phone.getText().toString());
            sqLiteDB.create(contact);

            Toast.makeText(this, "Inserted!", Toast.LENGTH_SHORT).show();
            finish();
        }else if(v == btnEdit){
            //contact.setName(name);
            startVoiceInput();
            phone.setText(contact.getPhone());


        }else if(v == btnDelete){
            sqLiteDB.delete(contact.getId());

            Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show();
            finish();
        }
        else if(v == btnDone){
            finish();
        }
        else if(v == btnSpeak){
            toSpeech = new TextToSpeech(ActActivity.this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int i) {
                    toSpeech.speak(phone.getText().toString(),TextToSpeech.QUEUE_FLUSH,null);
                }
            });
        }
    }
}
