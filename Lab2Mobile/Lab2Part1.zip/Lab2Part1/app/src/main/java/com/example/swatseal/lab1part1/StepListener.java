package com.example.swatseal.lab1part1;

/**
 * Created by karthik on 8/23/17.
 */

public interface StepListener {
    public void step(long timeNs);

}
