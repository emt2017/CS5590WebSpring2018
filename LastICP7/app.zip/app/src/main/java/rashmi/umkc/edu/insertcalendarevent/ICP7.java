package rashmi.umkc.edu.insertcalendarevent;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import com.example.insertcalendareventintent.R;

import java.util.Calendar;
import java.util.TimeZone;

public class ICP7 extends AppCompatActivity{

    CalendarView simpleCalendarView;
    TextView dateTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.icp7);

        simpleCalendarView = (CalendarView) findViewById(R.id.simpleCalendarView);
        dateTV = (TextView) findViewById(R.id.textView);

        //int year = (int) (1970 + simpleCalendarView.getDate()/3.154e+10);
        //int day = (int)((simpleCalendarView.getDate()-((year-1970)*3.154e+10))/8.64e+7); // ;
        //double month = simpleCalendarView.getDate()/2.628e+9;

        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        String startDate = String.valueOf((month+1)+"/"+day+"/"+year);
        dateTV.setText(startDate);

        simpleCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = (month+1)+"/"+dayOfMonth+"/"+year;
                dateTV.setText(date);
            }
        });
    }
}
